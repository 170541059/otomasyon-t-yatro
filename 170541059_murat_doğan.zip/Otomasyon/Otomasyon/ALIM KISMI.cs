﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Otomasyon
{
    public partial class ALIM_KISMI : Form
    {
        public static bool tiklama = false;
        public static string isim = "";
        public ALIM_KISMI()
        {
            InitializeComponent();
            textBox5.Text = (Bılet.bilet * 10).ToString();
            if (textBox5.Text == "0")
            {
                button1.Enabled = false;
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            tiklama = true;
            isim = textBox1.Text;
            this.Close();



        }
    }
}
