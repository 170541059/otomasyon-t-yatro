﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Otomasyon
{
    public partial class Form1 : Form
    {
        public static string resim;
        public static int tarih=0;

        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (tarih == 0)
            {
                MessageBox.Show("Bir tarih seçiniz");
                return;
            }
            resim = "1";
            Form bilet = new Bılet();
            bilet.Show();
            
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (tarih == 0)
            {
                MessageBox.Show("Bir tarih seçiniz");
                return;
            }
            resim = "2";
            Form bilet = new Bılet();
            bilet.Show();
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (tarih == 0)
            {
                MessageBox.Show("Bir tarih seçiniz");
                return;
            }
            resim = "3";
            Form bilet = new Bılet();
            bilet.Show();
            
            
        }

        private void cmb_tarih_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            if(cmb_tarih.SelectedItem.ToString()== "01-01-2019")
            {
                tarih = 1;

            }
            else if(cmb_tarih.SelectedItem.ToString() == "02-01-2019")
            {
                tarih = 2;
            }
            else
            {
                tarih = 0;
            }


        }
    }
}
