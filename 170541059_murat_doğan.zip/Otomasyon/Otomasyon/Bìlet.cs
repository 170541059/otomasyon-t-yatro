﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Otomasyon
{
    public partial class Bılet : Form
    {
        public static int bilet;



        public Bılet()
        {
            InitializeComponent();

            pictureBox1.Load(@"C:\Users\Hp\Desktop\" + Form1.resim + ".jpg");

            A1.Enabled = dolumu("A1");
            A2.Enabled = dolumu("A2");
            A3.Enabled = dolumu("A3");
            B1.Enabled = dolumu("B1");
            B2.Enabled = dolumu("B2");
            B3.Enabled = dolumu("B3");
            C1.Enabled = dolumu("C1");
            C2.Enabled = dolumu("C2");
            C3.Enabled = dolumu("C3");
            D1.Enabled = dolumu("D1");
            D2.Enabled = dolumu("D2");
            D3.Enabled = dolumu("D3");


        }

        private void checkBox16_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Bılet_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            bilet = 0;

            if (A1.Checked == true)
            {
                bilet++;
            }

            if (A2.Checked == true)
            {
                bilet++;
            }

            if (A3.Checked == true)
            {
                bilet++;
            }
            if (B1.Checked == true)
            {
                bilet++;
            }
            if (B2.Checked == true)
            {
                bilet++;
            }
            if (B3.Checked == true)
            {
                bilet++;
            }
            if (C1.Checked == true)
            {
                bilet++;
            }
            if (C2.Checked == true)
            {
                bilet++;
            }
            if (C3.Checked == true)
            {
                bilet++;
            }
            if (D1.Checked == true)
            {
                bilet++;
            }
            if (D2.Checked == true)
            {
                bilet++;
            }
            if (D3.Checked == true)
            {
                bilet++;
            }

            Form alım = new ALIM_KISMI();
            alım.ShowDialog();
            if(ALIM_KISMI.tiklama == true)
            {
                this.Hide();
                if (A1.Checked == true & A1.Enabled)
                {
                    baglanti("A1");
                }

                if (A2.Checked == true & A2.Enabled)
                {
                    baglanti("A2");
                }

                if (A3.Checked == true & A3.Enabled)
                {
                    baglanti("A3");
                }
                if (B1.Checked == true & B1.Enabled)
                {
                    baglanti("B1");
                }
                if (B2.Checked == true & B2.Enabled)
                {
                    baglanti("B2");
                }
                if (B3.Checked == true & B3.Enabled)
                {
                    baglanti("B3");
                }
                if (C1.Checked == true & C1.Enabled)
                {
                    baglanti("C1");
                }
                if (C2.Checked == true & C2.Enabled)
                {
                    baglanti("C2");
                }
                if (C3.Checked == true & C3.Enabled)
                {
                    baglanti("C3");
                }
                if (D1.Checked == true & D1.Enabled)
                {
                    baglanti("D1");
                }
                if (D2.Checked == true & D2.Enabled)
                {
                    baglanti("D2");
                }
                if (D3.Checked == true & D3.Enabled)
                {
                    baglanti("D3");
                }
                
                this.Close();


            }
        }

        public static bool dolumu (string koltuk)
        {
            bool dolum =true;
            OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=koltuklar.mdb");con.Open();
            OleDbCommand cmd = new OleDbCommand("SELECT dolumu FROM "+ Form1.tarih.ToString() + Form1.resim+ " WHERE koltuk = '" + koltuk +"'", con);
            OleDbDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                dolum = Convert.ToBoolean(dr["dolumu"]);
            }


            con.Close();
            
            return !dolum;
        }

        public static void baglanti(string koltuk)
        {
            OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=koltuklar.mdb"); con.Open();
            OleDbCommand cmd = new OleDbCommand("Update " + Form1.tarih.ToString() +Form1.resim+ " set dolumu=True where koltuk='" + koltuk + "'", con);
            OleDbDataReader dr = cmd.ExecuteReader();
            OleDbCommand cmd2 = new OleDbCommand("Update " + Form1.tarih.ToString() +Form1.resim + " set isim='" +ALIM_KISMI.isim+"' where koltuk='" + koltuk + "'", con);
            OleDbDataReader dr2 = cmd2.ExecuteReader();

        }

        public static void tersbaglanti(string koltuk)
        {
            OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=koltuklar.mdb"); con.Open();
            OleDbCommand cmd = new OleDbCommand("Update " + Form1.tarih.ToString() + Form1.resim + " set dolumu=False where koltuk='" + koltuk + "'", con);
            OleDbDataReader dr = cmd.ExecuteReader();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult seri = MessageBox.Show("Veri Tabanı Sıfırlansınmı", "Onay Kutusu", MessageBoxButtons.YesNo);
            if (seri == DialogResult.Yes)
            {

                this.Hide();
                tersbaglanti("A1");
                tersbaglanti("A2");
                tersbaglanti("A3");
                tersbaglanti("B1");
                tersbaglanti("B2");
                tersbaglanti("B3");
                tersbaglanti("C1");
                tersbaglanti("C2");
                tersbaglanti("C3");
                tersbaglanti("D1");
                tersbaglanti("D2");
                tersbaglanti("D3");
                this.Close();
            }
        }
    }
}
